﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LaserGame
{
    class Program
    {
        static void Main(string[] args)
        {
            // System.IO.StreamReader readfile = new System.IO.StreamReader();
            //         string values readfile.ReadToEnd()

            string info = "5,4\n" + "-1" + "\n" + "1,2RR" + "\n" + "1,3RR" + "\n" + "3,2L" + "\n"   + "-1"  + "\n" + "1,0V" + "\n"  + "-1";
           List<string>  values = prepData(info);


            Board theboard = new Board(values[0]);
            Laser theLazer = new Laser(values[2]);
            Mirror the_Mirror = new Mirror(values[1]);



            Game StartGame = new Game(theboard, theLazer, the_Mirror);

            Console.ReadKey();
            return;


        }

        public static List<string> prepData(string info)
        {
            
            List<string> values = info.Split(new string[] { "-1" }, StringSplitOptions.RemoveEmptyEntries).ToList<string>();


            if (values.Count() < 3)
            {

                Console.WriteLine("All Paramters are not \n available Please check file and resubmit");

            }
          else
            {

                Console.WriteLine("Argurment count: Three Arguments supplied : P \n");
               

            }
            return values;
        }
    }
}