﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using System.IO;

namespace LaserGame
{

    class Game
    {
        Board PlayBoard;
        Laser PlayLaser;
        Mirror GameMirror;
        Int64 currentRoomCol;
        Int64 currentRoomRow;


        public Int64 CurrentRoomCol
        {
            get
            {
                return currentRoomCol;
            }

            set
            {
                currentRoomCol = value;

            }


        }

        public Int64 CurrentRoomRow
        {
            get
            {
                return currentRoomRow;
            }

            set
            {
                currentRoomRow = value;

            }


        }


        public Game(Board board, Laser laser, Mirror mirror)
        {
            PlayBoard = board;
            PlayLaser = laser;
            GameMirror = mirror;
            validate(this);
            PlayGame(this);
        }

        

        private static void validate(Game TheGame)
        {


        }


        private static void PlayGame(Game TheGame)
        {
            Console.WriteLine("All inputs Validated \n let the Games Begin!");

            RuleBook GameRules = new RuleBook();
           


          

            if (TheGame.PlayLaser.LazerOrientation == "H")
            {

                Int64 InitialCol = TheGame.PlayLaser.LazerColPos;
                Int64 IntialRow = TheGame.PlayLaser.LazerRowPos;
                var LO = TheGame.PlayLaser.LazerOrientation;
                var LD = TheGame.PlayLaser.Direction;





                if (LD == "R")

                {


                    var Mirror_hit = ((from each_mirrow in TheGame.GameMirror.MirrorList.AsEnumerable()
                                       where Convert.ToInt64(each_mirrow.MirrowColPos) > InitialCol & Convert.ToInt64(each_mirrow.MirrowRowPos) == IntialRow
                                       select each_mirrow).ToList<Mirror>()).OrderBy(o => o.MirrowRowPos).ToList<Mirror>();


                    Mirror Imapact_mirror = Mirror_hit[0];

                    var col_pos = Imapact_mirror.MirrowColPos;
                    var col_Row = Imapact_mirror.MirrowRowPos;
                    string mirroO = Imapact_mirror.MirrowOrientation;
                    string mirroR = Imapact_mirror.MirrowReflec;



                    GameRules.RuleTable.AsEnumerable();
                    string lazer_refection = Imapact_mirror.Reflection(mirroO, mirroR, LD);



                    if (lazer_refection == "U" | lazer_refection == "D")
                    {
                        TheGame.PlayLaser.LazerOrientation = "V";

                    }
                    else if (lazer_refection == "L" | lazer_refection == "R")
                    {

                        TheGame.PlayLaser.LazerOrientation = "H";

                    }

                    // check for exit


                    // start new game if check fials 
                    TheGame.PlayLaser.LazerColPos = Convert.ToInt64(col_pos);
                    TheGame.PlayLaser.LazerRowPos = Convert.ToInt64(col_Row);
                    TheGame.PlayLaser.Direction = lazer_refection;


                    PlayGame(TheGame);

                }


                else if (LD == "L")

                {

                    var Mirror_hit = ((from each_mirrow in TheGame.GameMirror.MirrorList.AsEnumerable()
                                       where Convert.ToInt64(each_mirrow.MirrowColPos) < InitialCol & Convert.ToInt64(each_mirrow.MirrowRowPos) == IntialRow
                                       select each_mirrow).ToList<Mirror>()).OrderBy(o => o.MirrowRowPos).ToList<Mirror>();


                    Mirror Imapact_mirror = Mirror_hit[0];

                    var col_pos = Imapact_mirror.MirrowColPos;
                    var col_Row = Imapact_mirror.MirrowRowPos;
                    string mirroO = Imapact_mirror.MirrowOrientation;
                    string mirroR = Imapact_mirror.MirrowReflec;



                    GameRules.RuleTable.AsEnumerable();
                    string lazer_refection = Imapact_mirror.Reflection(mirroO, mirroR, LD);



                    if (lazer_refection == "U" | lazer_refection == "D")
                    {
                        TheGame.PlayLaser.LazerOrientation = "V";

                    }
                    else if (lazer_refection == "L" | lazer_refection == "R")
                    {

                        TheGame.PlayLaser.LazerOrientation = "H";

                    }

                    // check for exit


                    // start new game if check fials 
                    TheGame.PlayLaser.LazerColPos = Convert.ToInt64(col_pos);
                    TheGame.PlayLaser.LazerRowPos = Convert.ToInt64(col_Row);
                    TheGame.PlayLaser.Direction = lazer_refection;


                    PlayGame(TheGame);

                }



            }











            if (TheGame.PlayLaser.LazerOrientation == "V")
            {
                Int64 InitialCol = TheGame.PlayLaser.LazerColPos;
                Int64 IntialRow = TheGame.PlayLaser.LazerRowPos;
                var LO = TheGame.PlayLaser.LazerOrientation;
                var LD = TheGame.PlayLaser.Direction;

        


             

       



                    if(LD == "U")
                    {

                    var Mirror_hit = ((from each_mirrow in TheGame.GameMirror.MirrorList.AsEnumerable()
                                       where Convert.ToInt64(each_mirrow.MirrowColPos) == InitialCol
                                        & Convert.ToInt64(each_mirrow.MirrowRowPos) >= IntialRow
                                       select each_mirrow).ToList<Mirror>()).OrderBy(o => o.MirrowRowPos).ToList<Mirror>();




                    Mirror Imapact_mirror = Mirror_hit[0];

                        var col_pos = Imapact_mirror.MirrowColPos;
                        var col_Row = Imapact_mirror.MirrowRowPos;
                        string mirroO = Imapact_mirror.MirrowOrientation;
                        string mirroR = Imapact_mirror.MirrowReflec;



                        GameRules.RuleTable.AsEnumerable();
                        string lazer_refection =    Imapact_mirror.Reflection(mirroO,mirroR,LD);



                    if(lazer_refection == "U" | lazer_refection == "D")
                    {
                        TheGame.PlayLaser.LazerOrientation = "V";

                    } else if (lazer_refection == "L" | lazer_refection == "R")
                    {

                         TheGame.PlayLaser.LazerOrientation = "H";

                    }

                        // check for exit


                        // start new game if check fials 
                            TheGame.PlayLaser.LazerColPos = Convert.ToInt64(col_pos);
                        TheGame.PlayLaser.LazerRowPos = Convert.ToInt64(col_Row);
                        TheGame.PlayLaser.Direction = lazer_refection;


                          PlayGame(TheGame);

                    }
                    else if (LD == "D")

                    {


                    var Mirror_hit = ((from each_mirrow in TheGame.GameMirror.MirrorList.AsEnumerable()
                                       where Convert.ToInt64(each_mirrow.MirrowColPos) == InitialCol
                                        & Convert.ToInt64(each_mirrow.MirrowRowPos) >= IntialRow
                                       select each_mirrow).ToList<Mirror>()).OrderBy(o => o.MirrowRowPos).ToList<Mirror>();



                }

















              //  if (Mirror_hit.Count() == 0)
               // {
               //     Console.WriteLine("exit");

              //  }

            }


        }

    }

    class Board
    {

        // Set up Board Properties Rows and Cols
        private Int64 board_rows;
        private Int64 board_col;


        // Set up assessors for Board Properties
        public Int64 Board_Rows    // the board_rows property
        {
            get
            {
                return board_rows;
            }
        }
        public Int64 Board_Col    // the board_col property
        {
            get
            {
                return board_col;
            }
        }





        // Declear class constructor to take raw input values from file
        public Board(string values)
        {

            Validate_setupBoard(values);


        }



        private void Validate_setupBoard(string values)
        {
            List<string> valuesDimentions = values.Split(new string[] { ",", "\n" }, StringSplitOptions.RemoveEmptyEntries).ToList<string>();


            // Test Dimensions of Board, should only be exactly two; row and column. 
            if (valuesDimentions.Count > 2 | valuesDimentions.Count < 2)

            {

                Console.WriteLine("Board Dimensions Test: Fail \n Board has " + valuesDimentions.Count + " Dimensions only 2 Expected \n verify and Resubmit Game inputs");

            }


            // Test for valid dimensions  number can't be negetive or be equal to the intilized value of -9;
            Int64 isIntRow = -9;
            Int64 isIntCol = -9;
            Int64.TryParse(valuesDimentions[0], out isIntRow);
            Int64.TryParse(valuesDimentions[1], out isIntCol);


            if (isIntRow < 0 | isIntRow == -9 | isIntCol == -9 | isIntRow < 0)
            {
                Console.WriteLine("Board Row and Column Test: Fail \n Board has  negative values or Non numeric values \n verify and Resubmit Game inputs");
                Environment.Exit(0);
            } else
            {
                board_rows = isIntRow;
                board_col = isIntCol;

                Console.WriteLine("board dimesion Validation : PASSED");
                Console.WriteLine("board has " + board_rows + " Rows and " + board_col + " Cols \n");
            }








        }


    }

    class Laser
    {

        // Set up Lazer Properties Rows and Cols and Orientation
        private  Int64 lazerRowPos;                // the board_rows property
        private Int64 lazerColPos;               // LazerColPos property
        private string lazerOrientation;          // LazerOrientationy
        private string direction;


        // Set up assessors for Board Properties

        // the board_rows property
        public Int64 LazerRowPos
        {

            get
            {
                return lazerRowPos;
            }

            set
            {
                lazerRowPos = value;

            }
        }

        // LazerColPos property
        public Int64 LazerColPos
        {
            get
            {
                return lazerColPos;
            }
            set
            {
                lazerColPos = value;

            }
        }

        // LazerOrientationy
        public string LazerOrientation
        {
            get
            {
                return lazerOrientation;
            }
            set
            {
                lazerOrientation = value;

            }
        }

        // Lazer Direction

        public string Direction
        {
            get
            {
                return direction;
            }
             set
            {
                direction = value;
            }
        }




        // Constructor for Laser
        public Laser(string inputVal)

        {
            InitializeLazor(inputVal);

        }


        // Lazer intilization Method to set parameters of created lazer object
        public void InitializeLazor(string valuesLazor)
        {



            List<string> Lazerprop = valuesLazor.Split(new string[] { ",", "\n" }, StringSplitOptions.RemoveEmptyEntries).ToList<string>();


            // Test Dimensions of Board, should only be exactly two; row and column. 
            if (Lazerprop.Count < 2 | Lazerprop.Count > 2)

            {

                Console.WriteLine("Lazer Count Test: Fail \n There are  " + Lazerprop.Count + " in lazer set up only one expected \n verify and Resubmit Lazer inputs");

            }


            string LazerCol = Lazerprop[0];
            string LazerRow = Regex.Replace(Lazerprop[1], @"[A-Za-z\s]", string.Empty);
            lazerOrientation = Regex.Replace(Lazerprop[1], @"[\d-]", string.Empty);


            // Test for valid dimensions  number can't be negetive or be equal to the intilized value of -9;
            Int64 isIntCol = -9;
            Int64 isIntRow = -9;
            Int64.TryParse(LazerRow, out isIntRow);
            Int64.TryParse(LazerCol, out isIntCol);


            if (isIntRow < 0 | isIntRow == -9 | isIntCol == -9 | isIntRow < 0)
            {
                Console.WriteLine("Lazer Row and Column Test: Fail \n Lazer has  negative values or Non numeric values \n verify and Resubmit Lazer inputs");
                Environment.Exit(0);
            }
            else if (LazerOrientation != "V" & LazerOrientation != "H")
            {
                Console.WriteLine("Laser orientation is not valid");

            } else
            {


                lazerRowPos = isIntRow;
                lazerColPos = isIntCol;

                Console.WriteLine("Laser input is Validation : PASSED");
                Console.WriteLine("Laser is Entering in Row " + LazerRow + " Col " + LazerCol + " and oriented in " + LazerOrientation + " Position \n");


                if (LazerOrientation == "V" & LazerRowPos == 0)
                {
                    direction = "U";

                }
                else if (LazerOrientation == "V" & LazerRowPos != 0)
                {

                    direction = "D";

                }

                else if (LazerOrientation == "H" & LazerRowPos != 0)
                {

                    direction = "L";

                }

                else if (LazerOrientation == "H" & LazerRowPos == 0)
                {

                    direction = "R";

                }














            }



        }





    }

    class Mirror
    {

        private string mirrowRowPos;
        private string mirrowColPos;
        private string mirrowReflec;
        private string mirrowOrientation;


        public string MirrowRowPos    // the Name property
        {
            get
            {
                return mirrowRowPos;
            }
        }
        public string MirrowColPos    // the Name property
        {
            get
            {
                return mirrowColPos;
            }
        }
        public string MirrowReflec   // the Name property
        {
            get
            {
                return mirrowReflec;
            }
        }
        public string MirrowOrientation   // the Name property
        {
            get
            {
                return mirrowOrientation;
            }
        }


        public Mirror(string Mirrors)
        {
            InitizalizeMirrors(Mirrors);

        }
        public List<Mirror> MirrorList = new List<Mirror>();







        public void InitizalizeMirrors(string Mirrors)
        {


            List<string> MirrorArgs1 = Mirrors.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries).ToList<string>();

            foreach (string items in MirrorArgs1)
            {

                List<string> MirrorArgs = items.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
                mirrowColPos = MirrorArgs[0];
                mirrowRowPos = Regex.Replace(MirrorArgs[1], @"[A-Za-z\s]", string.Empty).Trim().ToString();
                mirrowReflec = Regex.Replace(MirrorArgs[1], @"[\d-]", string.Empty).Trim().ToString();


                if (mirrowReflec.Length == 2)
                {

                    mirrowOrientation = mirrowReflec.Substring(0, 1).ToString();
                    mirrowReflec = mirrowReflec.Substring(1, 1).ToString();
                }
                else
                {

                    mirrowOrientation = mirrowReflec.Substring(0, 1).ToString();
                    mirrowReflec = "";

                }








                Mirror Current_mirror = (Mirror)this.MemberwiseClone();

                // Mirror theMirror = new Mirror(mirrowRowPos, mirrowReflec, mirrowColPos);
                MirrorList.Add(Current_mirror);
            }



        }

        public List<Mirror> Get_Mirror()
        {
            return MirrorList;
        }


        public string Reflection(String Orientation, String reflection, string Direction )
        {
            RuleBook thebook = new RuleBook();
            DataTable GetBook =   thebook.RuleTable;


            //translate from Laser direction to mirror impact direction what is comming down as a leser beam 
            //would be comming from the Top before impact on the mirror. All cordinates switch

           if (Direction == "L")
            {
                Direction = "R";
            }
            else if (Direction == "R")
            {
                Direction = "L";

            }




                List<string> reflectionDirection = (from each_row in GetBook.AsEnumerable()
                                      where each_row.Field<string>("ORIENTATION") == Orientation & each_row.Field<string>("REFLECTION_MIRROR") == reflection & each_row.Field<string>("LASER_DIRECTION_IMPACT") == Direction
                                      select each_row.Field<string>("REFLECTION")).ToList<string>();

                    

            if(reflectionDirection.Count > 0)
            {
                return reflectionDirection[0];

            }
            else
            {
                return "NOT REFLECTED";
            }

            
        }

    }

    class RuleBook
    {

        public DataTable RuleTable;
         
        public   RuleBook()
        {

               System.IO.StreamReader ReadRulesBook = new System.IO.StreamReader("Rules2.txt");
                string RuleValues  =  ReadRulesBook.ReadToEnd();
                RuleTextToTable(RuleValues);



        }
    
    
        private  void RuleTextToTable(string RuleText)
        {

            RuleTable = new DataTable();
            List<string> RuleLines =   RuleText.Split(new string [] { "\n" },StringSplitOptions.None).ToList<string>();

            List<string> RuleBookHeader = RuleLines[0].Split(new char[] { '\t' }).ToList<string>();

            foreach(string Header in RuleBookHeader)
            {
                RuleTable.Columns.Add(Header.Replace("\r","").ToString());
                
            }

            for(int x = 1; x < RuleLines.Count;  x++)
            {

                RuleTable.Rows.Add(RuleLines[x].ToString().Replace("\r","").Split(new char[] { '\t' }));


            }




        }





    }






}
